package com.example.nathaniel.cs449_app;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Nathaniel on 11/26/2017.
 */
public class VConverterTest {
    @Test
    public void tsp_To_tsp() throws Exception {

    }

    @Test
    public void tsp_To_tbsp() throws Exception {

    }

    @Test
    public void tsp_To_oz() throws Exception {

    }

    @Test
    public void tsp_To_lbs() throws Exception {

    }

    @Test
    public void tsp_To_cup() throws Exception {

    }

    @Test
    public void tsp_To_pint() throws Exception {

    }

    @Test
    public void tsp_To_quart() throws Exception {

    }

    @Test
    public void tsp_To_gallon() throws Exception {

    }

    @Test
    public void tbsp_To_tsp() throws Exception {

    }

    @Test
    public void tbsp_To_tbsp() throws Exception {

    }

    @Test
    public void tbsp_To_oz() throws Exception {

    }

    @Test
    public void tbsp_To_lbs() throws Exception {

    }

    @Test
    public void tbsp_To_cup() throws Exception {

    }

    @Test
    public void tbsp_To_pint() throws Exception {

    }

    @Test
    public void tbsp_To_quart() throws Exception {

    }

    @Test
    public void tbsp_To_gallon() throws Exception {

    }

    @Test
    public void oz_To_tsp() throws Exception {

    }

    @Test
    public void oz_To_tbsp() throws Exception {

    }

    @Test
    public void oz_To_oz() throws Exception {

    }

    @Test
    public void oz_To_lbs() throws Exception {

    }

    @Test
    public void oz_To_cup() throws Exception {

    }

    @Test
    public void oz_To_pint() throws Exception {

    }

    @Test
    public void oz_To_quart() throws Exception {

    }

    @Test
    public void oz_To_gallon() throws Exception {

    }

    @Test
    public void lbs_To_tsp() throws Exception {

    }

    @Test
    public void lbs_To_tbsp() throws Exception {

    }

    @Test
    public void lbs_To_oz() throws Exception {

    }

    @Test
    public void lbs_To_lbs() throws Exception {

    }

    @Test
    public void lbs_To_cup() throws Exception {

    }

    @Test
    public void lbs_To_pint() throws Exception {

    }

    @Test
    public void lbs_To_quart() throws Exception {

    }

    @Test
    public void lbs_To_gallon() throws Exception {

    }

    @Test
    public void cup_To_tsp() throws Exception {

    }

    @Test
    public void cup_To_tbsp() throws Exception {

    }

    @Test
    public void cup_To_oz() throws Exception {

    }

    @Test
    public void cup_To_lbs() throws Exception {

    }

    @Test
    public void cup_To_cup() throws Exception {

    }

    @Test
    public void cup_To_pint() throws Exception {

    }

    @Test
    public void cup_To_quart() throws Exception {

    }

    @Test
    public void cup_To_gallon() throws Exception {

    }

    @Test
    public void pint_To_tsp() throws Exception {

    }

    @Test
    public void pint_To_tbsp() throws Exception {

    }

    @Test
    public void pint_To_oz() throws Exception {

    }

    @Test
    public void pint_To_lbs() throws Exception {

    }

    @Test
    public void pint_To_cup() throws Exception {

    }

    @Test
    public void pint_To_pint() throws Exception {

    }

    @Test
    public void pint_To_quart() throws Exception {

    }

    @Test
    public void pint_To_gallon() throws Exception {

    }

    @Test
    public void quart_To_tsp() throws Exception {

    }

    @Test
    public void quart_To_tbsp() throws Exception {

    }

    @Test
    public void quart_To_oz() throws Exception {

    }

    @Test
    public void quart_To_lbs() throws Exception {

    }

    @Test
    public void quart_To_cup() throws Exception {

    }

    @Test
    public void quart_To_pint() throws Exception {

    }

    @Test
    public void quart_To_quart() throws Exception {

    }

    @Test
    public void quart_To_gallon() throws Exception {

    }

    @Test
    public void gallon_To_tsp() throws Exception {

    }

    @Test
    public void gallon_To_tbsp() throws Exception {

    }

    @Test
    public void gallon_To_oz() throws Exception {

    }

    @Test
    public void gallon_To_lbs() throws Exception {

    }

    @Test
    public void gallon_To_cup() throws Exception {

    }

    @Test
    public void gallon_To_pint() throws Exception {

    }

    @Test
    public void gallon_To_quart() throws Exception {

    }

    @Test
    public void gallon_To_gallon() throws Exception {

    }

}